
class Mathematics:
    EPS = 1e-10
    INF = 1e+14

