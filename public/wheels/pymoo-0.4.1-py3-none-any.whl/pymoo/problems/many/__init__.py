from pymoo.problems.many.dtlz import *
from pymoo.problems.many.cdtlz import *
from pymoo.problems.many.wfg import *

