from pymoo.problems.multi.bnh import *
from pymoo.problems.multi.carside import *
from pymoo.problems.multi.ctp import *
from pymoo.problems.multi.kursawe import *
from pymoo.problems.multi.osy import *
from pymoo.problems.multi.tnk import *
from pymoo.problems.multi.truss2d import *
from pymoo.problems.multi.welded_beam import *
from pymoo.problems.multi.zdt import *

